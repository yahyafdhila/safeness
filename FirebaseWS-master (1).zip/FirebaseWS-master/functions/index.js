const functions = require('firebase-functions');
const admin = require('firebase-admin');
admin.initializeApp();
var db = admin.firestore();

const twilio = require('twilio');
//const accountSid = functions.config().twilio.sid
//const authToken  = functions.config().twilio.token

const client = new twilio("ACe2dd46a6fd3c2eb0f42864ea9f73ba1c", "cdece79d5dfb973bc0e4c9af4fcd35b8");

const USER_COLLECTION = 'users';
const ALERT_COLLECTION = 'alerts';
const INVITATION_COLLECTION = 'invitations';
const CONTACT_COLLECTION = 'contacts';
const RECEIVED_COLLECTION = 'received';

exports.sendSMS = functions.https.onCall((data, context) => {
    data.numbers.forEach(async (num) => {
        const textMessage = {
            body: data.message + " https://tinyurl.com/safenessapp",
            to: num,
            from: "SafeNess"
        }
        const msg = await client.messages.create(textMessage)
    })
})

exports.sendInvitation = functions.firestore
    .document(`${INVITATION_COLLECTION}/{userID}/${INVITATION_COLLECTION}/{invitationID}`)
    .onCreate(async (snap, context) => {
        const userID = context.params.userID;
        const userRef = await db.collection(USER_COLLECTION).doc(userID).get();
        const user = userRef.data();
        const userToken = user.token;
        const payload = {
            notification: {
                title: 'Nouvelle invitation !',
                body: `${snap.data().userName} vous a envoyé une invitation.`,
            },
            data: {
                actionType: "invitation"
            }
        };
        const response = await admin.messaging().sendToDevice(userToken, payload);
    });

exports.sendAcceptationInvitation = functions.firestore
    .document(`${INVITATION_COLLECTION}/{userUid}/${INVITATION_COLLECTION}/{invitationID}`)
    .onUpdate(async (change, context) => {
        const newValue = change.after.data();
        if (newValue.status == "ACCEPTED") {
            const currentUserUid = context.params.userUid;
            const currentUserRef = await db.collection(USER_COLLECTION).doc(currentUserUid).get();
            const currentUser = currentUserRef.data();
            console.log(currentUser);
            const userRef = await db.collection(USER_COLLECTION)
                .doc(newValue.senderUid)
                .collection(CONTACT_COLLECTION)
                .doc(currentUser.uuid)
                .set({
                    userUid: currentUser.uuid,
                    phoneNumber: currentUser.phoneNumber,
                    image: currentUser.image,
                    userName: currentUser.userName
                })
            const payload = {
                notification: {
                    title: 'Invitation acceptée!',
                    body: `${currentUser.userName} a accepté votre invitation.`,
                },
                data: {
                    actionType: "accepted"
                }
            };
            const me = await db.collection(USER_COLLECTION).doc(newValue.senderUid).get();
            const token = me.data().token;
            const response = await admin.messaging().sendToDevice(token, payload);
        }
    });


exports.sendAlerts = functions.firestore
    .document(`${USER_COLLECTION}/{userUid}/${ALERT_COLLECTION}/{alertID}`)
    .onCreate(async (snap, context) => {
        const userUid = context.params.userUid;
        const contacts = await db.collection(USER_COLLECTION).doc(userUid).collection(CONTACT_COLLECTION).get();
        contacts.forEach(async (doc) => {
            const user = await db.collection(USER_COLLECTION).doc(doc.data().userUid).get();
            const currentUser = await db.collection(USER_COLLECTION).doc(userUid).get()
            const alert = await user.ref.collection(RECEIVED_COLLECTION).doc(context.params.alertID).set(snap.data());
            var IBody = ""
            if (snap.data().type == 1) {
                IBody = `${currentUser.data().userName} a besoin d'aide`
            } else {
                IBody = `${currentUser.data().userName} souhaite partager sa position avec vous`
            }
            const payload = {
                notification: {
                    title: 'Nouvelle alerte!',
                    body: IBody,
                },
                data: {
                    actionType: "alert",
                    alertId: context.params.alertID,
                    userId: userUid
                }
            };

            if (snap.data().type == 1) {
                const textMessage = {
                    body: `${currentUser.data().userName} a besoin d'aide`,
                    to: user.data().fullPhone,
                    from: "SafeNess"
                }
                const sms = await client.messages.create(textMessage)
                    .then(message => console.log(message.sid));
            }
            const response = await admin.messaging().sendToDevice(user.data().token, payload);
        })
    });

exports.sendClosedAlerts = functions.firestore
    .document(`${USER_COLLECTION}/{userUid}/${ALERT_COLLECTION}/{alertID}`)
    .onUpdate(async (change, context) => {
        const newValue = change.after.data();
        console.log(newValue.status);

        if (newValue.status == "CLOSED") {
            const userUid = context.params.userUid;
            console.log("UserId = " + userUid);

            const contacts = await db.collection(USER_COLLECTION).doc(userUid).collection(CONTACT_COLLECTION).get();
            const currentUser = await db.collection(USER_COLLECTION).doc(userUid).get()

            contacts.forEach(async (doc) => {
                const payload = {
                    notification: {
                        title: 'Alerte fermée!',
                        body: `${currentUser.data().userName} est maintenant en sécurité.`,
                    },
                    data: {
                        actionType: "closed",
                        alertId: context.params.alertID,
                        userId: userUid
                    }
                };
                const tokenref = await db.collection(USER_COLLECTION).doc(doc.data().userUid).get();
                console.log("USER = " + tokenref.data().fullPhone);
                console.log("USER = " + tokenref.data().token);
                console.log("USER = " + tokenref.data().toString());

                const textMessage = {
                    body: `${currentUser.data().userName} est maintenant en sécurité.`,
                    to: tokenref.data().fullPhone,
                    from: "SafeNess"
                }
                if(newValue.type == 1){
                const sms = await client.messages
                    .create(textMessage)
                    .then(message => console.log(message.sid));
                }
                const response = await admin.messaging().sendToDevice(tokenref.data().token, payload);
            })
        }
    });